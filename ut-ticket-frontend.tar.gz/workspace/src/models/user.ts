export interface User {
  id?: string;
  autoTaskId?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  roleCode: string;
}
