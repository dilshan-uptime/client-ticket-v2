export interface GlobalModalProps {
  open: boolean;
  title: string;
  bodyId?: string | null;
  params?: any;
  width?: string;
}
