export interface UserRole {
  roleId: string;
  roleName: string;
}
