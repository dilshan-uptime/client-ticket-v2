export const UITestComponent = ({ message }: { message: string }) => {
  return <div className="text-sm text-gray-800">Test Body: {message}</div>;
};
