export const roleTypes = {
  ADMIN: "ADMIN",
  SUPER_ADMIN: "SUPER_ADMIN",
  CLIENT: "CLIENT",
};
