import type { AppRouteDto } from "@/models/common";

export const ClientRoutes: AppRouteDto[] = [];
