export const HomePage = () => {
  return <>HOME</>;
};
