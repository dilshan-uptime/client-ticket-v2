export const TicketPage = () => {
  return (
    <div className="flex flex-col h-screen max-h-screen overflow-auto">
      <h2 className="text-2xl font-bold text-center mt-2">
        Ticket TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
      </h2>
    </div>
  );
};
